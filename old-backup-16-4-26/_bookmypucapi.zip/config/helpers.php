<?php

function sendResponse($success, $message, $data = null, $code = 200) {
    http_response_code($code);

    echo json_encode([
        "success" => $success,
        "message" => $message,
        "data" => $data
    ]);

    exit; // ✅ MUST
}

function getRequestData() {
    $input = file_get_contents("php://input");
    $data = json_decode($input, true);
    return $data ?? [];
}