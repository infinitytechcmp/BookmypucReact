<?php
require_once __DIR__ . '/../config/database.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}


// Allow POST only
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        "success" => false,
        "message" => "Invalid request method"
    ]);
    exit;
}

// Get JSON data
$data = json_decode(file_get_contents("php://input"), true);

// Validate
if (!isset($data['booking_id'])) {
    echo json_encode([
        "success" => false,
        "message" => "Booking ID is required"
    ]);
    exit;
}

$database = new Database();
$db = $database->getConnection();

try {
    // 🔍 Get booking + user + center details
    $query = "SELECT 
                b.id, b.date, b.time,
                u.email, u.name as user_name,
                c.name as center_name
              FROM bookings b
              JOIN users u ON b.user_id = u.id
              JOIN centers c ON b.center_id = c.id
              WHERE b.id = :id";

    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $data['booking_id']);
    $stmt->execute();

    $booking = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$booking) {
        echo json_encode([
            "success" => false,
            "message" => "Booking not found"
        ]);
        exit;
    }

    // ✉️ Email details
    $to = $booking['email'];
    $subject = "Booking Confirmed - BookMyPUC ✅";

    $message = "
    <html>
    <body style='font-family: Arial;'>
        <h2>🎉 Booking Confirmed</h2>
        <p>Hello <b>{$booking['user_name']}</b>,</p>
        <p>Your booking has been successfully confirmed.</p>

        <p><b>Center:</b> {$booking['center_name']}</p>
        <p><b>Date:</b> {$booking['date']}</p>
        <p><b>Time:</b> {$booking['time']}</p>

        <br>
        <p>Thank you for using BookMyPUC 🚗</p>
    </body>
    </html>
    ";

    // Headers
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8\r\n";
    $headers .= "From: BookMyPUC <noreply@bookmypuc.com>\r\n";
    
    if (mail($to, $subject, $message, $headers)) {
    file_put_contents("mail_log.txt", "Mail function executed");
} else {
    file_put_contents("mail_log.txt", "Mail failed");
}

    // Send mail
    if (mail($to, $subject, $message, $headers)) {
        echo json_encode([
            "success" => true,
            "message" => "Email sent successfully"
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "Failed to send email"
        ]);
    }

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Error: " . $e->getMessage()
    ]);
}